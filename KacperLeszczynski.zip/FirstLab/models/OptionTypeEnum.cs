﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstLab.models
{
    public enum OptionTypeEnum
    {
        Nothing,
        Vertical,
        Horizontal
    }
}
