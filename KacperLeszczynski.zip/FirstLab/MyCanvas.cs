﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstLab
{
    //public class MyCanvas : PictureBox
    //{
    //    private Bitmap drawArea;

    //    public MyCanvas()
    //    {
    //        MouseDown += MyCanvas_MouseDown;

    //        drawArea = new Bitmap(Canvas.Size.Width, Canvas.Size.Height);
    //        Canvas.Image = drawArea;
    //        using (Graphics g = Graphics.FromImage(drawArea))
    //        {
    //            g.Clear(Color.White);
    //        }
    //    }

    //    private void MyCanvas_MouseDown(object sender, MouseEventArgs e)
    //    {
    //        // Handle the MouseDown event for the custom PictureBox control
    //        int x = e.X;
    //        int y = e.Y;

    //        MessageBox.Show($"Mouse clicked at X: {x}, Y: {y}");
    //    }

    //}
}
